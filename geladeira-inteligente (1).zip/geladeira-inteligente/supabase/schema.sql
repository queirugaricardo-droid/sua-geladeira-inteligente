-- =====================================================================
-- Geladeira Inteligente - banco de dados seguro
-- Cole no Supabase: SQL Editor > New query > Run  (pode rodar mais de uma vez)
-- =====================================================================

-- ---------- Tabelas ----------
create table if not exists public.estoque_ideal (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  name text not null,
  quantity numeric not null default 1,
  unit text not null default 'un',
  category text not null default 'Outros',
  created_at timestamptz not null default now()
);

create table if not exists public.analises_foto (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  summary text,
  detected_foods jsonb not null default '[]'::jsonb,
  shopping_list jsonb,
  recipes jsonb,
  created_at timestamptz not null default now()
);

create index if not exists estoque_ideal_user_idx on public.estoque_ideal(user_id);
create index if not exists analises_foto_user_idx on public.analises_foto(user_id, created_at desc);

-- ---------- Validação dos dados (ninguém grava lixo nem dados gigantes) ----------
alter table public.estoque_ideal drop constraint if exists estoque_name_chk;
alter table public.estoque_ideal add constraint estoque_name_chk
  check (char_length(btrim(name)) between 1 and 60);

alter table public.estoque_ideal drop constraint if exists estoque_qty_chk;
alter table public.estoque_ideal add constraint estoque_qty_chk
  check (quantity > 0 and quantity <= 9999);

alter table public.estoque_ideal drop constraint if exists estoque_unit_chk;
alter table public.estoque_ideal add constraint estoque_unit_chk
  check (unit in ('un','kg','L','ml','pacote','caixa'));

alter table public.estoque_ideal drop constraint if exists estoque_cat_chk;
alter table public.estoque_ideal add constraint estoque_cat_chk
  check (char_length(btrim(category)) between 1 and 40);

alter table public.analises_foto drop constraint if exists analises_summary_chk;
alter table public.analises_foto add constraint analises_summary_chk
  check (summary is null or char_length(summary) <= 1000);

alter table public.analises_foto drop constraint if exists analises_foods_chk;
alter table public.analises_foto add constraint analises_foods_chk
  check (jsonb_typeof(detected_foods) = 'array' and jsonb_array_length(detected_foods) <= 100);

alter table public.analises_foto drop constraint if exists analises_shopping_chk;
alter table public.analises_foto add constraint analises_shopping_chk
  check (shopping_list is null or pg_column_size(shopping_list) < 50000);

alter table public.analises_foto drop constraint if exists analises_recipes_chk;
alter table public.analises_foto add constraint analises_recipes_chk
  check (recipes is null or (jsonb_typeof(recipes) = 'array' and jsonb_array_length(recipes) <= 10));

-- ---------- Triggers de proteção ----------
-- 1) O dono de uma linha nunca pode ser trocado
create or replace function public.block_user_id_change()
returns trigger language plpgsql set search_path = '' as $$
begin
  if new.user_id <> old.user_id then
    raise exception 'Não é permitido alterar o dono do registro.';
  end if;
  return new;
end $$;

drop trigger if exists estoque_block_owner on public.estoque_ideal;
create trigger estoque_block_owner before update on public.estoque_ideal
  for each row execute function public.block_user_id_change();

drop trigger if exists analises_block_owner on public.analises_foto;
create trigger analises_block_owner before update on public.analises_foto
  for each row execute function public.block_user_id_change();

-- 2) Limite de itens por usuário (evita abuso e custo de armazenamento)
create or replace function public.limit_estoque_rows()
returns trigger language plpgsql set search_path = '' as $$
begin
  if (select count(*) from public.estoque_ideal where user_id = new.user_id) >= 200 then
    raise exception 'Limite de 200 itens no estoque atingido.' using errcode = 'P0001';
  end if;
  return new;
end $$;

drop trigger if exists estoque_limit on public.estoque_ideal;
create trigger estoque_limit before insert on public.estoque_ideal
  for each row execute function public.limit_estoque_rows();

-- 3) Minimização de dados: guarda só as 50 análises mais recentes de cada pessoa
create or replace function public.trim_old_analyses()
returns trigger language plpgsql set search_path = '' as $$
begin
  delete from public.analises_foto
  where user_id = new.user_id
    and id not in (
      select id from public.analises_foto
      where user_id = new.user_id
      order by created_at desc
      limit 50
    );
  return null;
end $$;

drop trigger if exists analises_trim on public.analises_foto;
create trigger analises_trim after insert on public.analises_foto
  for each row execute function public.trim_old_analyses();

-- ---------- RLS: cada pessoa só enxerga e altera os próprios dados ----------
alter table public.estoque_ideal enable row level security;
alter table public.estoque_ideal force row level security;
alter table public.analises_foto enable row level security;
alter table public.analises_foto force row level security;

-- Visitantes sem login (anon) não têm NENHUM acesso
revoke all on public.estoque_ideal from anon, public;
revoke all on public.analises_foto from anon, public;
grant select, insert, update, delete on public.estoque_ideal to authenticated;
grant select, insert, update, delete on public.analises_foto to authenticated;

-- remove políticas antigas
drop policy if exists "estoque: dono acessa" on public.estoque_ideal;
drop policy if exists "analises: dono acessa" on public.analises_foto;
drop policy if exists estoque_select on public.estoque_ideal;
drop policy if exists estoque_insert on public.estoque_ideal;
drop policy if exists estoque_update on public.estoque_ideal;
drop policy if exists estoque_delete on public.estoque_ideal;
drop policy if exists analises_select on public.analises_foto;
drop policy if exists analises_insert on public.analises_foto;
drop policy if exists analises_update on public.analises_foto;
drop policy if exists analises_delete on public.analises_foto;

-- (select auth.uid()) é mais rápido: avalia uma vez por consulta
create policy estoque_select on public.estoque_ideal for select to authenticated
  using ((select auth.uid()) = user_id);
create policy estoque_insert on public.estoque_ideal for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy estoque_update on public.estoque_ideal for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy estoque_delete on public.estoque_ideal for delete to authenticated
  using ((select auth.uid()) = user_id);

create policy analises_select on public.analises_foto for select to authenticated
  using ((select auth.uid()) = user_id);
create policy analises_insert on public.analises_foto for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy analises_update on public.analises_foto for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy analises_delete on public.analises_foto for delete to authenticated
  using ((select auth.uid()) = user_id);

-- ---------- LGPD: a pessoa pode apagar a própria conta e todos os dados ----------
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then
    raise exception 'Não autenticado.';
  end if;
  delete from auth.users where id = auth.uid();  -- apaga em cascata estoque e análises
end $$;

revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
