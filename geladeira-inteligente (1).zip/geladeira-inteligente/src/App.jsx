import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase, supabaseReady } from "./supabase";
import { apiFetch } from "./api";

const fridgeImage =
  "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80";

const defaultInventory = [
  { name: "Tomate", quantity: 6, unit: "un", category: "Hortifrúti" },
  { name: "Alface", quantity: 1, unit: "un", category: "Hortifrúti" },
  { name: "Leite", quantity: 2, unit: "L", category: "Laticínios" },
  { name: "Iogurte", quantity: 3, unit: "un", category: "Laticínios" },
  { name: "Queijo", quantity: 1, unit: "un", category: "Laticínios" },
  { name: "Frango", quantity: 2, unit: "kg", category: "Carnes" },
  { name: "Água", quantity: 6, unit: "un", category: "Bebidas" }
];

function getFoodIcon(name = "") {
  const n = name.toLowerCase();

  if (n.includes("tomate")) return "🍅";
  if (n.includes("alface") || n.includes("salada")) return "🥬";
  if (n.includes("leite")) return "🥛";
  if (n.includes("iogurte")) return "🥣";
  if (n.includes("queijo")) return "🧀";
  if (n.includes("ovo")) return "🥚";
  if (n.includes("frango")) return "🍗";
  if (n.includes("bov") || n.includes("carne")) return "🥩";
  if (n.includes("maçã") || n.includes("uva") || n.includes("laranja")) return "🍊";
  if (n.includes("água")) return "💧";
  if (n.includes("suco")) return "🧃";
  if (n.includes("pão") || n.includes("brot")) return "🍞";
  return "🍽️";
}

function getCategoryEmoji(category = "") {
  const c = category.toLowerCase();
  if (c.includes("hort")) return "🥬";
  if (c.includes("latic")) return "🥛";
  if (c.includes("carn")) return "🥩";
  if (c.includes("beb")) return "🥤";
  return "🧺";
}

function money(value) {
  return Number(value || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function App() {
  const [tab, setTab] = useState("inicio");
  const [session, setSession] = useState(null);
  const [authReady, setAuthReady] = useState(!supabaseReady);

  const [inventory, setInventory] = useState([]);
  const [latest, setLatest] = useState(null);

  const [uploading, setUploading] = useState(false);
  const [aiBusy, setAiBusy] = useState("");
  const [preview, setPreview] = useState(null);
  const [notice, setNotice] = useState("");
  const [toast, setToast] = useState(null);

  const [form, setForm] = useState({
    item: "",
    quantity: "1",
    unit: "un",
    category: "Outros"
  });

  const user = session?.user || null;

  const showToast = useCallback((text, type = "error") => {
    setToast({ text, type, id: Date.now() });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(timer);
  }, [toast]);

  // Se sair da conta (ou excluir), volta para o início
  useEffect(() => {
    if (authReady && !user && ["estoque", "relatorio", "conta"].includes(tab)) {
      setTab("inicio");
    }
  }, [authReady, user, tab]);

  /* ------------------------------ sessão/login ----------------------------- */

  useEffect(() => {
    if (!supabaseReady) return;

    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthReady(true);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  /* ------------------------------ dados do banco --------------------------- */

  const loadInventory = useCallback(async (userId) => {
    const { data, error } = await supabase
      .from("estoque_ideal")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: true });

    if (error) {
      setNotice(`Erro ao carregar estoque: ${error.message}`);
      return;
    }

    // Primeiro acesso: cria o estoque ideal padrão
    if (!data || data.length === 0) {
      const { data: seeded, error: seedError } = await supabase
        .from("estoque_ideal")
        .insert(defaultInventory.map((item) => ({ ...item, user_id: userId })))
        .select();

      if (seedError) {
        setNotice(`Erro ao criar estoque inicial: ${seedError.message}`);
        return;
      }
      setInventory(seeded || []);
      return;
    }

    setInventory(data);
  }, []);

  const loadLatest = useCallback(async (userId) => {
    const { data } = await supabase
      .from("analises_foto")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    setLatest(data || null);
  }, []);

  useEffect(() => {
    if (user) {
      loadInventory(user.id);
      loadLatest(user.id);
    } else {
      setInventory([]);
      setLatest(null);
    }
  }, [user?.id, loadInventory, loadLatest]);

  /* --------------------------------- estoque ------------------------------- */

  async function addItem() {
    if (!user) return goToLogin();
    const qty = Number(String(form.quantity).replace(",", "."));
    if (!form.item.trim()) return;
    if (!Number.isFinite(qty) || qty <= 0 || qty > 9999) {
      setNotice("Informe uma quantidade entre 0 e 9999.");
      return;
    }

    const newItem = {
      user_id: user.id,
      name: form.item.trim(),
      quantity: qty,
      unit: form.unit,
      category: form.category
    };

    const { data, error } = await supabase.from("estoque_ideal").insert([newItem]).select().single();

    if (error) {
      setNotice(`Erro ao adicionar: ${error.message}`);
      return;
    }

    setInventory((prev) => [...prev, data]);
    setForm({ ...form, item: "", quantity: "1" });
    setNotice("");
  }

  function patchLocal(id, patch) {
    setInventory((prev) => prev.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  }

  async function saveItem(id, patch) {
    const { error } = await supabase.from("estoque_ideal").update(patch).eq("id", id);
    if (error) setNotice(`Erro ao salvar: ${error.message}`);
  }

  async function deleteItem(id) {
    const { error } = await supabase.from("estoque_ideal").delete().eq("id", id);
    if (error) {
      setNotice(`Erro ao remover: ${error.message}`);
      return;
    }
    setInventory((prev) => prev.filter((item) => item.id !== id));
  }

  const categories = useMemo(() => {
    const map = new Map();

    inventory.forEach((item) => {
      if (!map.has(item.category)) map.set(item.category, []);
      map.get(item.category).push({ ...item, icon: getFoodIcon(item.name) });
    });

    const detected = (latest?.detected_foods || []).map((item, index) => ({
      id: `detected-${index}`,
      name: item.name,
      quantity: item.quantity || 1,
      unit: item.unit || "un",
      icon: getFoodIcon(item.name),
      readonly: true
    }));

    const list = Array.from(map.entries()).map(([name, items]) => ({
      name,
      emoji: getCategoryEmoji(name),
      items
    }));

    if (detected.length) {
      list.push({ name: "Reconhecidos", emoji: "📷", items: detected });
    }

    return list;
  }, [inventory, latest]);

  /* --------------------------------- IA (Claude) --------------------------- */

  function goToLogin() {
    setNotice("");
    setTab("auth");
  }

  async function handleImageUpload(event) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;

    if (!user) return goToLogin();

    setPreview(URL.createObjectURL(file));

    const formData = new FormData();
    formData.append("image", file);

    try {
      setUploading(true);
      setNotice("");
      const data = await apiFetch("/api/analyze", { method: "POST", body: formData });
      setLatest(data.analysis);
      setTab("relatorio");
    } catch (error) {
      showToast(error.message);
    } finally {
      setUploading(false);
    }
  }

  async function runAi(kind, path) {
    try {
      setAiBusy(kind);
      const data = await apiFetch(path, { method: "POST" });
      setLatest(data.analysis);
    } catch (error) {
      showToast(error.message);
    } finally {
      setAiBusy("");
    }
  }

  /* --------------------------------- render -------------------------------- */

  if (!authReady) {
    return <div className="page-shell loading-screen">Carregando…</div>;
  }

  const shopping = latest?.shopping_list;
  const recipes = latest?.recipes;

  return (
    <div className="page-shell">
      <header className="topbar">
        <div className="brand-row">
          <div className="brand-mark">🧊</div>
          <div className="brand-name">Geladeira Inteligente</div>
        </div>

        <nav className="nav-tabs">
          <button
            className={tab === "inicio" ? "tab active" : "tab"}
            onClick={() => setTab("inicio")}
          >
            Início
          </button>
          <button
            className={tab === "estoque" ? "tab active" : "tab"}
            onClick={() => (user ? setTab("estoque") : goToLogin())}
          >
            Estoque ideal
          </button>
          <button
            className={tab === "relatorio" ? "tab active" : "tab"}
            onClick={() => (user ? setTab("relatorio") : goToLogin())}
          >
            Último relatório
          </button>
        </nav>

        <div className="top-actions">
          {user ? (
            <>
              <button
                className={tab === "conta" ? "user-chip active" : "user-chip"}
                title="Minha conta e privacidade"
                onClick={() => setTab("conta")}
              >
                {user.user_metadata?.name || user.email}
              </button>
              <button className="ghost-btn" onClick={() => supabase.auth.signOut()}>
                Sair
              </button>
            </>
          ) : (
            <button className="ghost-btn" onClick={goToLogin}>
              Entrar
            </button>
          )}
          <button className="cta small" onClick={() => setTab("inicio")}>
            Analisar agora
          </button>
        </div>
      </header>

      {notice && <div className="notice">{notice}</div>}

      {tab === "auth" && <AuthPanel onDone={() => setTab("inicio")} />}

      {tab === "conta" && user && <AccountPanel user={user} showToast={showToast} />}

      {tab === "inicio" && (
        <>
          <section className="hero">
            <div className="hero-copy">
              <div className="badge-green">Visão inteligente para sua cozinha</div>

              <h1>
                Sua geladeira
                <br />
                sob controle em
                <br />
                um clique.
              </h1>

              <p>
                Fotografe, descubra o que está faltando e receba sua lista de compras
                com preços estimados — sem conferir prateleira por prateleira.
              </p>
            </div>

            <div className="fridge-scene">
              <div className="fridge-shell">
                <img src={fridgeImage} alt="Geladeira" />
                <div className="floating-tag left-tag">Leite · 700 ml</div>
                <div className="floating-tag right-tag">Ovos · 6 un</div>
              </div>
            </div>
          </section>

          <section className="process">
            <div className="section-kicker">COMO FUNCIONA</div>
            <h2>Da foto à lista de compras em três passos.</h2>

            <div className="steps">
              <div className="step">
                <div className="step-icon">📷</div>
                <div className="step-number">01</div>
                <h3>Fotografe</h3>
                <p>Tire uma foto da sua geladeira aberta.</p>
              </div>

              <div className="step">
                <div className="step-icon">🧠</div>
                <div className="step-number">02</div>
                <h3>A IA analisa</h3>
                <p>A visão inteligente identifica o que você tem e o que está faltando.</p>
              </div>

              <div className="step">
                <div className="step-icon">🛒</div>
                <div className="step-number">03</div>
                <h3>Lista pronta</h3>
                <p>Receba a lista automática, categorizada e com estimativa de preços.</p>
              </div>
            </div>
          </section>

          <section className="insight-banner">
            <div className="insight-left">
              <div className="fridge-mini-wrap">
                {preview ? (
                  <img src={preview} alt="Preview da geladeira" />
                ) : (
                  <img src={fridgeImage} alt="Geladeira em miniatura" />
                )}

                <div className="mini-card">
                  <span className="icon">🧊</span>
                  <div>
                    <strong>
                      {latest?.detected_foods?.length || 12} itens reconhecidos
                    </strong>
                    <small>
                      {uploading ? "Analisando imagem..." : "Análise visual concluída"}
                    </small>
                  </div>
                </div>
              </div>
            </div>

            <div className="insight-right">
              <div className="small-label">INTELIGÊNCIA QUE SIMPLIFICA</div>
              <h2>Menos tempo conferindo. Mais clareza para comprar.</h2>
              <p>
                Nossa visão computacional reconhece os alimentos visíveis, compara com
                seu estoque ideal e transforma tudo em decisões simples para o dia a dia.
              </p>

              {user ? (
                <label className="upload-button">
                  <input type="file" accept="image/*" onChange={handleImageUpload} />
                  <span>{uploading ? "Analisando..." : "Experimentar agora"}</span>
                </label>
              ) : (
                <button className="upload-button" onClick={goToLogin}>
                  Entrar para experimentar
                </button>
              )}
            </div>
          </section>
        </>
      )}

      {tab === "estoque" && user && (
        <section className="inventory-panel">
          <div className="form-card">
            <h3>Adicionar alimento ao estoque ideal</h3>

            <div className="form-grid">
              <div className="input-group wide">
                <label>Alimento</label>
                <input
                  placeholder="Ex.: iogurte natural"
                  maxLength={60}
                  value={form.item}
                  onChange={(e) => setForm({ ...form, item: e.target.value })}
                  onKeyDown={(e) => e.key === "Enter" && addItem()}
                />
              </div>

              <div className="input-group">
                <label>Quantidade</label>
                <input
                  value={form.quantity}
                  onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                />
              </div>

              <div className="input-group">
                <label>Unidade</label>
                <select
                  value={form.unit}
                  onChange={(e) => setForm({ ...form, unit: e.target.value })}
                >
                  <option value="un">un</option>
                  <option value="kg">kg</option>
                  <option value="L">L</option>
                  <option value="ml">ml</option>
                </select>
              </div>

              <div className="input-group">
                <label>Categoria</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                >
                  <option value="Outros">Outros</option>
                  <option value="Hortifrúti">Hortifrúti</option>
                  <option value="Laticínios">Laticínios</option>
                  <option value="Bebidas">Bebidas</option>
                  <option value="Carnes">Carnes</option>
                </select>
              </div>

              <button className="cta add-btn" onClick={addItem}>
                + Adicionar
              </button>
            </div>
          </div>

          <div className="category-list">
            {categories.map((category) => (
              <div key={category.name} className="category-card">
                <div className="category-header">
                  <span className="category-title">
                    {category.emoji} {category.name}
                  </span>
                  <span className="chip">{category.items.length}</span>
                </div>

                <div className="item-list">
                  {category.items.map((item) => (
                    <div className="item-row" key={item.id}>
                      <div className="item-main">
                        <span className="item-icon">{item.icon}</span>
                        <span>{item.name}</span>
                      </div>

                      <div className="item-controls">
                        {item.readonly ? (
                          <>
                            <input value={item.quantity} readOnly />
                            <select value={item.unit} disabled>
                              <option value={item.unit}>{item.unit}</option>
                            </select>
                          </>
                        ) : (
                          <>
                            <input
                              value={item.quantity}
                              onChange={(e) => patchLocal(item.id, { quantity: e.target.value })}
                              onBlur={() =>
                                saveItem(item.id, { quantity: Number(item.quantity) || 1 })
                              }
                            />
                            <select
                              value={item.unit}
                              onChange={(e) => {
                                patchLocal(item.id, { unit: e.target.value });
                                saveItem(item.id, { unit: e.target.value });
                              }}
                            >
                              {["un", "kg", "L", "ml", "pacote", "caixa"].map((u) => (
                                <option key={u} value={u}>
                                  {u}
                                </option>
                              ))}
                            </select>
                            <button
                              className="delete-btn"
                              aria-label={`Remover ${item.name}`}
                              onClick={() => deleteItem(item.id)}
                            >
                              🗑
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {tab === "relatorio" && user && (
        <section className="report-panel">
          <h2>Último relatório</h2>
          <p>IA analisa a geladeira e sugere compras com base no estoque ideal.</p>

          {!latest && (
            <div className="report-box">
              <h3>Nenhuma análise ainda</h3>
              <p>Envie uma foto da sua geladeira na tela inicial para gerar o primeiro relatório.</p>
              <label className="upload-button">
                <input type="file" accept="image/*" onChange={handleImageUpload} />
                <span>{uploading ? "Analisando..." : "Enviar foto"}</span>
              </label>
            </div>
          )}

          {latest?.summary && (
            <div className="report-box">
              <h3>Resumo da análise</h3>
              <p>{latest.summary}</p>
            </div>
          )}

          {latest?.detected_foods?.length > 0 && (
            <div className="report-list">
              {latest.detected_foods.map((item, index) => (
                <div key={`${item.name}-${index}`} className="report-item">
                  <span>
                    {getFoodIcon(item.name)} {item.name}
                  </span>
                  <span>
                    {item.quantity} {item.unit}
                  </span>
                  <span>{Math.round((item.confidence || 0.9) * 100)}%</span>
                </div>
              ))}
            </div>
          )}

          {latest && (
            <div className="report-actions">
              <button
                className="cta"
                disabled={Boolean(aiBusy)}
                onClick={() => runAi("shopping", "/api/shopping-list")}
              >
                {aiBusy === "shopping" ? "Gerando lista…" : "🛒 Gerar lista de compras"}
              </button>
              <button
                className="cta"
                disabled={Boolean(aiBusy) || !latest.detected_foods?.length}
                onClick={() => runAi("recipes", "/api/recipes")}
              >
                {aiBusy === "recipes" ? "Pensando…" : "🍳 Sugerir receitas"}
              </button>
              <label className="ghost-btn file-btn">
                <input type="file" accept="image/*" onChange={handleImageUpload} />
                <span>{uploading ? "Analisando..." : "📷 Nova foto"}</span>
              </label>
            </div>
          )}

          {shopping && (
            <div className="report-box">
              <h3>Lista de compras</h3>
              {shopping.items?.length ? (
                <div className="report-list">
                  {shopping.items.map((item, index) => (
                    <div key={`${item.name}-${index}`} className="report-item">
                      <span>
                        {getFoodIcon(item.name)} {item.name}
                      </span>
                      <span>
                        {item.quantity} {item.unit}
                      </span>
                      <span>{money(item.estimatedPrice)}</span>
                    </div>
                  ))}
                  <div className="report-item total-row">
                    <span>Total estimado</span>
                    <span />
                    <span>{money(shopping.total)}</span>
                  </div>
                </div>
              ) : (
                <p>Nada está faltando no seu estoque ideal. 🎉</p>
              )}
              {shopping.tip && <p className="tip">💡 {shopping.tip}</p>}
            </div>
          )}

          {recipes?.length > 0 && (
            <div className="recipes-grid">
              {recipes.map((recipe, index) => (
                <div key={`${recipe.title}-${index}`} className="recipe-card">
                  <h3>{recipe.title}</h3>
                  {recipe.time && <small>⏱ {recipe.time}</small>}
                  {recipe.uses?.length > 0 && (
                    <p>
                      <strong>Usa:</strong> {recipe.uses.join(", ")}
                    </p>
                  )}
                  {recipe.missing?.length > 0 && (
                    <p>
                      <strong>Falta:</strong> {recipe.missing.join(", ")}
                    </p>
                  )}
                  <ol>
                    {(recipe.steps || []).map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ol>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      <footer className="site-footer">
        <span>🔒 Suas fotos não são armazenadas e seus dados são privados.</span>
        {user && (
          <button onClick={() => setTab("conta")}>Privacidade e minha conta</button>
        )}
      </footer>

      {toast && (
        <div className={`toast ${toast.type}`} role="status" aria-live="polite" key={toast.id}>
          <span>{toast.text}</span>
          <button aria-label="Fechar aviso" onClick={() => setToast(null)}>
            ✕
          </button>
        </div>
      )}
    </div>
  );
}

/* ------------------------------ tela de login ------------------------------ */

function AuthPanel({ onDone }) {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  if (!supabaseReady) {
    return (
      <section className="auth-wrap">
        <div className="auth-card">
          <h2>Configure o Supabase</h2>
          <p>
            Preencha <code>VITE_SUPABASE_URL</code> e <code>VITE_SUPABASE_ANON_KEY</code> no
            arquivo <code>.env</code> e reinicie com <code>npm run dev</code>.
          </p>
        </div>
      </section>
    );
  }

  async function submit(event) {
    event.preventDefault();
    setMessage({ type: "", text: "" });

    if (mode === "signup" && !(/[A-Za-z]/.test(password) && /\d/.test(password))) {
      setMessage({ type: "error", text: "Use uma senha com letras e números." });
      return;
    }

    setBusy(true);

    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { name } }
        });
        if (error) throw error;

        if (!data.session) {
          setMessage({
            type: "ok",
            text: "Conta criada! Confirme seu e-mail para entrar."
          });
        } else {
          onDone();
        }
      } else if (mode === "reset") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin
        });
        if (error) throw error;
        setMessage({ type: "ok", text: "Enviamos um link para redefinir sua senha." });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        onDone();
      }
    } catch (error) {
      setMessage({ type: "error", text: translateAuthError(error.message) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="auth-wrap">
      <form className="auth-card" onSubmit={submit}>
        <h2>
          {mode === "login" && "Entrar"}
          {mode === "signup" && "Criar conta"}
          {mode === "reset" && "Recuperar senha"}
        </h2>
        <p>Seu estoque e seus relatórios ficam salvos na sua conta.</p>

        {mode === "signup" && (
          <div className="input-group">
            <label>Nome</label>
            <input value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
        )}

        <div className="input-group">
          <label>E-mail</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        {mode !== "reset" && (
          <div className="input-group">
            <label>Senha</label>
            <input
              type="password"
              minLength={8}
              maxLength={72}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            {mode === "signup" && (
              <small className="hint">Mínimo de 8 caracteres, com letras e números.</small>
            )}
          </div>
        )}

        {message.text && <div className={`msg ${message.type}`}>{message.text}</div>}

        <button className="cta large" type="submit" disabled={busy}>
          {busy
            ? "Aguarde…"
            : mode === "login"
            ? "Entrar"
            : mode === "signup"
            ? "Criar conta"
            : "Enviar link"}
        </button>

        <div className="auth-links">
          {mode !== "login" && (
            <button type="button" onClick={() => setMode("login")}>
              Já tenho conta
            </button>
          )}
          {mode !== "signup" && (
            <button type="button" onClick={() => setMode("signup")}>
              Criar conta
            </button>
          )}
          {mode === "login" && (
            <button type="button" onClick={() => setMode("reset")}>
              Esqueci a senha
            </button>
          )}
        </div>
      </form>
    </section>
  );
}

function AccountPanel({ user, showToast }) {
  const [confirmText, setConfirmText] = useState("");
  const [busy, setBusy] = useState("");

  async function exportData() {
    try {
      setBusy("export");

      const [estoque, analises] = await Promise.all([
        supabase.from("estoque_ideal").select("*").eq("user_id", user.id),
        supabase.from("analises_foto").select("*").eq("user_id", user.id)
      ]);

      if (estoque.error || analises.error) {
        throw new Error("Não foi possível exportar seus dados agora.");
      }

      const content = {
        conta: { email: user.email, criadaEm: user.created_at },
        estoque_ideal: estoque.data,
        analises: analises.data
      };

      const blob = new Blob([JSON.stringify(content, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "meus-dados-geladeira-inteligente.json";
      link.click();
      URL.revokeObjectURL(url);
      showToast("Seus dados foram exportados.", "ok");
    } catch (error) {
      showToast(error.message);
    } finally {
      setBusy("");
    }
  }

  async function deleteAccount() {
    if (confirmText !== "EXCLUIR") return;

    try {
      setBusy("delete");
      const { error } = await supabase.rpc("delete_my_account");
      if (error) throw error;
      await supabase.auth.signOut();
    } catch {
      showToast("Não foi possível excluir a conta agora. Tente novamente.");
      setBusy("");
    }
  }

  return (
    <section className="account-panel">
      <h2>Minha conta e privacidade</h2>
      <p className="account-email">{user.email}</p>

      <div className="report-box">
        <h3>Como protegemos seus dados</h3>
        <ul className="privacy-list">
          <li>Suas fotos são analisadas e descartadas na hora. Nós não guardamos a imagem.</li>
          <li>Seu estoque e seus relatórios só podem ser lidos por você, com proteção direto no banco de dados.</li>
          <li>A conexão é criptografada e a senha nunca fica visível para nós.</li>
          <li>Mantemos somente suas 50 análises mais recentes.</li>
        </ul>
      </div>

      <div className="report-box">
        <h3>Baixar meus dados</h3>
        <p>Receba uma cópia de tudo o que está salvo na sua conta, em formato JSON.</p>
        <button className="cta" onClick={exportData} disabled={busy !== ""}>
          {busy === "export" ? "Preparando…" : "Baixar meus dados"}
        </button>
      </div>

      <div className="report-box danger-box">
        <h3>Excluir minha conta</h3>
        <p>
          Isso apaga sua conta, seu estoque e todos os relatórios de forma permanente. Não dá para
          desfazer. Digite <strong>EXCLUIR</strong> para confirmar.
        </p>
        <div className="danger-row">
          <input
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value)}
            placeholder="EXCLUIR"
            aria-label="Digite EXCLUIR para confirmar"
          />
          <button
            className="danger-btn"
            onClick={deleteAccount}
            disabled={confirmText !== "EXCLUIR" || busy !== ""}
          >
            {busy === "delete" ? "Excluindo…" : "Excluir tudo"}
          </button>
        </div>
      </div>
    </section>
  );
}

function translateAuthError(message = "") {
  const m = message.toLowerCase();
  if (m.includes("rate limit") || m.includes("too many")) {
    return "Muitas tentativas. Aguarde alguns minutos e tente de novo.";
  }
  if (m.includes("invalid login")) return "E-mail ou senha incorretos.";
  if (m.includes("already registered")) return "Este e-mail já tem cadastro.";
  if (m.includes("email not confirmed")) return "Confirme seu e-mail antes de entrar.";
  if (m.includes("password")) return "A senha precisa ter pelo menos 6 caracteres.";
  return message;
}

export default App;
