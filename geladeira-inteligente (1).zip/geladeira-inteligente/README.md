# Geladeira Inteligente

React + Vite + Node, com **Claude (Anthropic)** analisando a foto da geladeira, **login** e **banco de dados** no Supabase.

## O que a IA faz
- **Analisa a foto** e identifica os alimentos (visão computacional do Claude).
- **Gera a lista de compras** comparando o estoque ideal com o que foi detectado, com preço estimado em R$.
- **Sugere receitas** com o que você tem na geladeira.

## Login e banco de dados (Supabase)
- Cadastro, login e recuperação de senha por e-mail.
- Cada usuário tem seu próprio estoque ideal e seus relatórios (protegidos por RLS).

## Segurança (resumo)
**Banco de dados**
- RLS ativado e forçado: cada pessoa só lê, cria, altera e apaga os **próprios** dados. Visitantes sem login não acessam nada.
- O servidor **não usa a chave `service_role`**. Ele acessa o banco com o token do próprio usuário, então o RLS vale também no backend.
- Validações no banco (tamanho, unidades, quantidade), bloqueio de troca de dono, limite de 200 itens de estoque e retenção das 50 últimas análises.
- A foto da geladeira **não é armazenada**: é processada em memória e descartada.

**Servidor**
- `helmet` (cabeçalhos de segurança), CORS restrito aos seus domínios, limite de requisições por IP e por usuário, cota diária de análises.
- Valida o conteúdo real da imagem (não só a extensão), limita tamanho (5 MB) e sanitiza tudo que a IA devolve.
- Mensagens de erro genéricas: detalhes internos ficam só no log.
- Proteção contra *prompt injection* (texto escrito em rótulos ou nomes de itens não vira comando para a IA).

**Privacidade (LGPD)**
- Tela "Minha conta" com **baixar meus dados** e **excluir conta e tudo que está salvo**.

## 1. Requisitos
- Node.js 18+
- Chave da Anthropic: https://console.anthropic.com
- Projeto gratuito no Supabase: https://supabase.com

## 2. Configurar o Supabase
1. Crie um projeto no Supabase.
2. Vá em **SQL Editor > New query**, cole o conteúdo de `supabase/schema.sql` e clique em **Run**.
3. Vá em **Project Settings > API** e copie `Project URL` e `anon public key`. A `service_role` **não é necessária**: não use e não coloque em lugar nenhum.
4. Em **Authentication** (painel do Supabase), faça este checklist:
   - **Providers > Email**: mantenha "Confirm email" **ligado** em produção.
   - **Sign In / Providers > Password**: tamanho mínimo 8 e ative "Prevent use of leaked passwords" (planos que oferecem).
   - **URL Configuration**: coloque o seu domínio em "Site URL" e em "Redirect URLs".
   - **Rate Limits**: mantenha os limites padrão contra tentativas em massa.
   - Opcional: ative MFA (autenticação em dois fatores).

## 3. Configurar o projeto
```bash
cp .env.example .env
```
Preencha o `.env` com as chaves. Nunca compartilhe a chave da Anthropic e nunca envie o `.env` para o GitHub (já está no `.gitignore`).

## 4. Rodar
```bash
npm install
npm run dev
```
- Frontend: http://localhost:5173
- Backend: http://localhost:3001 (teste em /api/health)

## API (exige login: header `Authorization: Bearer <token>`)
| Rota | O que faz |
|---|---|
| `POST /api/analyze` | Recebe `image` (até 5 MB), analisa com Claude e salva |
| `POST /api/shopping-list` | Gera a lista de compras da última análise |
| `POST /api/recipes` | Sugere 3 receitas da última análise |
| `GET /api/health` | Status do servidor |

## Custos
A Anthropic cobra por uso. Para economizar, troque `CLAUDE_MODEL` no `.env` por um modelo menor (ex.: `claude-haiku-5-5`).

## Deploy
O frontend (`npm run build`) pode ir para Vercel/Netlify, e o `server.js` para Render/Railway.

Em produção:
1. Configure as mesmas variáveis de ambiente e defina `ALLOWED_ORIGINS` com o seu domínio (ex.: `https://suageladeira.com.br`).
2. Se o servidor ficar atrás de proxy (Render, Railway), ative `TRUST_PROXY=1`.
3. O `vercel.json` já traz os cabeçalhos de segurança (CSP, HSTS etc.). Se a API ficar em outro endereço, inclua essa URL em `connect-src` e crie um *rewrite* de `/api` para ela.
4. Use sempre HTTPS.
